﻿using System;
using System.Data.SqlClient;
using System.Text;
using System.Web.Mvc;
using BCTS.Util;

namespace DemoPrueba.Controllers
{
    public class PruebaController : Controller
    {
        // GET: Prueba
        public ActionResult Vista()
        {
            return View();
        }

        public String ListarClientes()
        {
            try
            {
                var Connection = new SqlConnection().SetConnectionStringKey("ConBD"); //Creación de conexión
                var Command = Connection.CreateProcedure("UP_COMBO_CLIENTES"); //Creación del procedure
                var StringBuilder = new StringBuilder(); //Instancia del strinbuilder

                StringBuilder.Append("Cliente"); //Definición de nombres de tablas

                //Ingreso de primera tabla con el número de cabeceras (2, Nombres y tipos de datos)
                StringBuilder.AddTable(2);
                using (var DataReader = Command.ExecuteReader()) DataReader.AddTableData(StringBuilder); //Llenado de data usando el datareader

                return StringBuilder.ToString();
            }
            catch (Exception ex)
            {
                return "Error: " + ex.SaveException();
            }
        }
    }
}