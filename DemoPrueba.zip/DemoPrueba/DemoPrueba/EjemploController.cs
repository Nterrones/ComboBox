﻿using BCTS.Util;
using System;
using System.Data.SqlClient;
using System.Text;
using System.Web.Mvc;

namespace BCTS.Arquitectura.Web.Controllers
{
    public class EjemploController : Controller
    {
        public ActionResult Vista()
        {
            return View();
        }

        public string ListarDesarrolladores()
        {
            try
            {
                var Connection = new SqlConnection().SetConnectionStringKey("ConBD"); //Creación de conexión
                var Command = Connection.CreateProcedure("UP_LIS_DESARROLLADORES"); //Creación del procedure
                var StringBuilder = new StringBuilder(); //Instancia del strinbuilder

                StringBuilder.Append("Desarrolladores"); //Definición de nombres de tablas

                //Ingreso de primera tabla con el número de cabeceras (2, Nombres y tipos de datos)
                StringBuilder.AddTable(2); 
                using (var DataReader = Command.ExecuteReader()) DataReader.AddTableData(StringBuilder); //Llenado de data usando el datareader

                return StringBuilder.ToString();
            }
            catch (Exception ex)
            {
                return "Error: " + ex.SaveException();
            }
        }
    }
}