﻿worker.addView('frPrincipal', { fn: ['if', 'on', 'for', 'model', 'attr', 'enabled', 'class', 'http', 'event', 'wait', 'csv', 'modal'], autoCreate: false }, function ($data, $handler, $http, $event, $wait, $csv, $modal) {

    var args = {
        url: document.getElementById('url').value + 'Prueba/',
        date: worker.date,
        wait: $wait.set,
        scroll: $wait.scroll,
    };

    function fnInicio() {
        args.wait(true);

        $data.Objeto = {
            Client: ''
        };
        

        $http.post(args.url + 'ListarClientes').then(
            function (data) {
                var hasError = data.substring(0, 4);

                if (hasError == 'Error') {
                    console.log(data);
                }
                else {
                    $csv.split(data, args);

                    $data.Cliente = args.Cliente.Items;
                }

                $handler.create();
                args.wait(false);
            },
            function (error) {
                console.log(error);
                args.wait(false);
            });
	}
	
	fnInicio();

});