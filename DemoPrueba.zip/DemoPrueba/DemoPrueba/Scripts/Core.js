﻿var worker;
//Core del framework
(function () {

    var separatorScope = '%';
    var separatorParam = ':';
    var separatorMany = '|';

    var functionUpdate = {};
    var functionCreate = {};
    var functionService = {};

    var viewArray = {};
    var workerArray = {};
    var forTemplateArray = {};

    var workerObject = null;

    function bindEvent(element, name, callback) {
        if (element.addEventListener) element.addEventListener(name, callback);
        else if (element.attachEvent) element.attachEvent('on' + name, callback);
    }

    function wrongParametersMsg(view, functionName, attribute) {
        return view.getFullName() + ': Wrong parameters at the function "' + functionName.toUpperCase() + '" with the value "' + attribute + '".';
    }

    function wrongTypeMsg(view, functionName, attribute, type) {
        return wrongParametersMsg(view, functionName, attribute) + ' the function requires "' + type.toUpperCase() + '" object type.';
    }

    function moreThanOneMsg(type, name, container) {
        return 'There is more than one ' + type.toUpperCase() + ' with the name "' + name + '" in ' + container.toUpperCase();
    }

    //Implementación de comparación de cadenas
    function startsWith(baseString, baseStringLength, searchString, searchStringLength) {
        var i = 0;
        var j = searchStringLength;

        if (searchStringLength > baseStringLength) {
            return false;
        }

        for (i = 0; i < j; i++)
            if (baseString[i] != searchString[i])
                return false;

        return true;
    }

    //Verificación si empieza por un path
    function startsWithPath(baseString, baseStringLength, searchString, searchStringLength) {
        return startsWith(baseString, baseStringLength, searchString, searchStringLength) && (baseStringLength == searchStringLength || baseString[searchStringLength] == '.' || baseString[searchStringLength] == separatorParam);
    }

    //Verifica si el path en actualización afecta al path del elemento
    function isPathDependent(args, path) {
        return startsWithPath(path, path.length, args.path, args.pathLength);
    }

    //Obtiene el resultado si es una función
    function getFunctionValue(data) {
        if (data == null) return null;

        while (data instanceof Function) data = data();

        return data;
    }

    //Obtiene el valor de un objeto en base a una ruta (Ejm: Compra.Usuario.Nombre)
    function getValue(data, path, args) {
        var value = null;
        var valueNames = null;
        var valueNamesCount = path.length;

        //Para obtener el scope de la data
        for (i = 0; i < valueNamesCount; i++)
            if (path[i] !== separatorScope)
                break;

        //Validando si debe buscar el scope y si este existe
        if (i > 0 && args.scope && args.scope.length >= i) {
            //Obteniendo la data del scope y el path sin los %(spScope)
            value = args.scope[i - 1];
            valueNames = path.substr(i);
        }
        else {
            //Si no tiene scope usa la data y el path obtenido
            value = data;
            valueNames = path;
        }

        //Separando los accesos a variables
        valueNames = valueNames.split('.');
        valueNamesCount = valueNames.length;

        for (i = 0; i < valueNamesCount; i++) {
            value = getFunctionValue(value);

            value = value[valueNames[i]];

            if (value == null) {
                return null;
            }

        }

        return value;
    }

    //Verifica que el valor no sea nulo
    var getNonNullValue = function (data, path, args) {
        if (data == null) {
            console.warn(args.getFullName() + ': Could not find the path "' + path + '".');
            return null;
        }
        return data;
    };

    //Obtiene el valor de un objeto en base a una ruta (Ejm: Compra.Usuario.Nombre)
    function getObjectValue(data, path, args) {
        return getNonNullValue(getFunctionValue(getValue(data, path, args)), path, args);
    }

    function getBooleanValue(data, path, args) {
        if (path[0] == '!') {
            return !getObjectValue(data, path.substr(1), args);
        }
        else {
            return getObjectValue(data, path, args);
        }
    }

    //Genera un ID unico
    function getId() {
        return (Math.floor(Math.random() * 899999999) + 100000000).toString();
    }

    //Crea el objeto worker y luego lo registra 
    function getWorkerObject(type) {
        var id = getId();

        //Encapsula el id y el tipo
        var workerObject = {
            type: type,
            id: id,
            equals: function (workerObject) { return workerObject ? workerObject.id == id : false; },
            getFullName: function () { return type + "/" + id; }
        };

        //Valida que no exista dos objetos con el mismo id, no debería pasar pero por sea caso
        if (workerArray[id]) {
            console.error('Core: There is another worker object with the id "' + id + '".');
        }

        workerArray[id] = workerObject;

        return workerObject;
    }

    //Crea el objeto event handler que hereda del objeto worker
    function getEventHandlerObject(type) {
        var eventHandler = getWorkerObject(type ? type : 'event');
        var eventListeners = {};

        //Invoca el evento con los parametros definidos
        function invoke(eventName, parameters) {
            var eventListener = eventListeners[eventName];
            var event = null;

            if (eventListener)
                for (event in eventListener)
                    eventListener[event].callback.apply(null, parameters);
        }

        //Agrega un enlace a un evento
        function setHook(eventName, workerObject, callback) {
            var eventListener = eventListeners[eventName];

            if (eventListener == null) {
                eventListener = {};
                eventListeners[eventName] = eventListener;
            }

            if (eventListener[workerObject.id]) {
                console.error(workerObject.getFullName() + ': There is already a hook of that worker object for that event in this handler.');
                return;
            }

            eventListener[workerObject.id] = { id: workerObject.id, callback: callback };
        }

        //Quita el enelace a un evento
        function removeHook(eventName, workerObject) {
            var eventListener = eventListeners[eventName];

            if (eventListener == null) return;

            eventListener[workerObject.id] = undefined;
        }

        eventHandler.invoke = invoke;
        eventHandler.setHook = setHook;
        eventHandler.removeHook = removeHook;

        setHook('afterRemove', workerObject, function () { workerArray[eventHandler.id] = undefined; });

        return eventHandler;
    }

    //Inicializa las funciones que trabajaran con los atributos del framework
    function initAttributeHandlers() {

        //Obtiene el nombre de la propiedad donde se escribe el valor de un elemento HTML
        function getHtmlSetterName(element) {
            switch (element.tagName) {
                case 'INPUT':
                    switch (element.type) {
                        case 'checkbox':
                            return 'checked';
                        case 'file':
                            return null;
                        default:
                            return 'value';
                    }
                case 'TEXTAREA':
                case 'SELECT':
                    return 'value';
                default:
                    return 'innerText';
            }
        }

        //Obtiene el nombre de la propiedad donde se setea el valor de un elemento HTML
        function getHtmlGetterName(element) {
            switch (element.tagName) {
                case 'INPUT':
                    switch (element.type) {
                        case 'checkbox':
                            return 'checked';
                        case 'file':
                            return 'files';
                        default:
                            return 'value';
                    }
                case 'TEXTAREA':
                case 'SELECT':
                    return 'value';
                default:
                    console.error('Core: The function model can not be used in this element "' + element.tagName + '".');
                    return null;
            }
        }

        //Ejecuta la función w-attr="path:nombreAtributo:stringBase?"
        function doAttr(element, data, args, attribute) {
            var params = attribute.split(separatorParam);

            if (params.length < 2) {
                console.error(wrongParametersMsg(args, 'attr', attribute));
                return;
            }

            var value = getObjectValue(data, params[0], args);
            var attributeName = params[1];

            if (attributeName.trim() == '') {
                console.error(wrongParametersMsg(args, 'attr', attribute));
                return;
            }

            if (value != null) {
                if (params.length == 3) {
                    value = params[2].replace(new RegExp('#', 'g'), value).replace(/\|/g, separatorParam);
                }

                element.removeAttribute('w-attr');
                element.setAttribute(attributeName, value);
            }
        }

        //Ejecuta la función w-style="path:nombreAtributo?"
        function doStyle(element, data, args, attribute) {
            var params = attribute.split(separatorParam);
            var paramsCount = params.length;
            var value = null;

            //Valida si es un estilo por propiedad
            if (paramsCount === 2) {
                value = getObjectValue(data, params[0], args);

                if (value) element.style[params[1]] = value;
            }
            //O por objeto que se leera las propiedades
            else if (paramCount == 1) {
                value = getObjectValue(data, params[0], args);

                if (value == null) return;

                //Valida que sea un objeto
                if (value instanceof Object) {
                    for (var key in value)
                        element.style[key] = value[key];
                }
                else {
                    console.error(wrongTypeMsg(args, 'style', attribute, 'object'));
                }
            }
            else {
                console.error(wrongParametersMsg(args, 'style', attribute));
            }
        }

        //Ejecuta la función w-class="path"
        function doClass(element, data, args, attribute) {
            var value = getObjectValue(data, attribute, args);
            var classBase = element.getAttribute('w-class-base');

            if (value == null) return;
            element.className = (classBase ? (classBase + ' ') : ('')) +  value;
        }

        //Ejecuta la función w-if="path"
        function doIf(element, data, args, attribute) {
            var value = getBooleanValue(data, attribute, args);
            var defValue = element.getAttribute('w-if-default');

            if (value == null) return;

            if (defValue == null) defValue = 'block';

            if (typeof (value) === 'boolean' || value instanceof Boolean) {
                element.style.display = value == true ? defValue : 'none';
            }
            else {
                console.error(wrongTypeMsg(args, 'if', attribute, 'boolean'));
            }
        }

        //Ejecuta la función w-enabled="path"
        function doEnabled(element, data, args, attribute) {
            var value = getBooleanValue(data, attribute, args);

            if (value == null) return;

            if (typeof (value) === 'boolean' || value instanceof Boolean) {
                element.disabled = !value;
            }
            else {
                console.error(wrongTypeMsg(args, 'enabled', attribute, 'boolean'));
            }
        }

        //Ejecuta la función w-bind="path:parser?" (enlace de datos de una dirección)
        function doBind(element, data, args, attribute) {
            var params = attribute.split(separatorParam);

            var value = getObjectValue(data, params[0], args);
            var propName = getHtmlSetterName(element);
            var parser = null;

            if (propName == null) return;

            if (params.length > 1) {
                parser = getNonNullValue(getValue(data, params[1], args), params[1], args);

                if (parser == null || value == null) return;

                if (!(parser instanceof Function)) {
                    console.error(wrongTypeMsg(args, 'bind', attribute, 'function'));
                    return;
                }

                element[propName] = parser(value);
            }
            else if (value != null) {
                element[propName] = value;
            }
        }

        function doHook(element, data, args, attribute, params) {
            //valida que tenga solo 3 parametros (callback : evento : path)
            if (params.length > 1 && params.length < 4) {
                var callback = getNonNullValue(getValue(data, params[0], args), params[0], args);
                var value = params.length > 2 ? getObjectValue(data, params[2], args) : null;

                if (callback == null) return;

                if (callback instanceof Function) {
                    bindEvent(element, params[1], function (e) { callback.apply(null, value ? [value, element, e] : [element, e]); });
                }
                else {
                    console.error(wrongTypeMsg(args, 'on', attribute, 'function'));
                }
            }
            else {
                console.error(wrongParametersMsg(args, 'on', attribute));
            }
        }

        function getModelEventName(element) {
            switch (element.tagName) {
                case 'TEXTAREA':
                    return 'input';
                case 'INPUT':
                    switch (element.type) {
                        case 'text':
                            return 'input';
                        default:
                            return 'change';
                    }
                case 'SELECT':
                    return 'change';
                default:
                    return null;
            }
        }

        //Ejecuta la función w-model="path:parser?" (enlace de datos bidireccional)
        function doModel(element, data, args, attribute) {
            var params = attribute.split(':');
            var value = data;
            var valueNames = params[0].split('.');
            var valueNamesCount = valueNames.length;

            //Si el objeto no tiene un acceso a variable
            if (valueNamesCount < 2) {
                console.error(wrongParametersMsg(args, 'model', attribute));
                return;
            }
            /*
            //Si el elemento esta dentro de un scope(for) no se puede enlazar
            else if (args.scope.length > 0) {
                console.error(wrongParametersMsg(args, 'model', attribute) + ' the path is incorrect.');
                return;
            }
            */

            valueNamesCount--; //No se quiere acceder al ultimo valor así que se quita 1 al total de accesos

            for (i = 0; i < valueNamesCount; i++) {
                //Obteniendo el valor accediendo variable por variable
                value = value[valueNames[i]];

                if (value == null) break;
            }

            var propName = getHtmlGetterName(element);

            if (value && propName) {
                var valueAccesorName = valueNames[valueNamesCount];

                if (element.tagName == 'SELECT' && element.getAttribute('multiple')) {
                    bindEvent(element, 'change', function () {
                        var selection = [];
                        var i = 0;
                        var c = element.children.length;

                        for (i = 0; i < c; i++)
                            if (element.children[i].selected)
                                selection.push(element.children[i].value);

                        value[valueAccesorName] = selection;
                    });
                }
                else {
                    element.setAttribute('w-bind', attribute);
                    doBind(element, data, args, attribute);

                    bindEvent(element, getModelEventName(element), function () {
                        value[valueAccesorName] = element[propName];
                    });
                }
            }
        }

        //Ejecuta la función w-on="callback:evento:path?" (enlace de eventos), El callback recibe 2 parametros, el del path y el elemento HTML
        function doOn(element, data, args, attribute) {
            var params = attribute.split(separatorMany);
            var i = 0;
            var c = params.length;

            for (i = 0; i < c; i++) doHook(element, data, args, attribute, params[i].split(separatorParam));
        }

        //Ejecuta la función w-for="path:variableIteracion" (iteración de datos)
        function doFor(element, data, args, attribute) {
            var params = attribute.split(separatorParam);

            //valida que tenga solo 2 parametros (path : variable de iteración)
            if (params.length != 2) {
                console.error(wrongParametersMsg(args, 'for', attribute));
                return;
            }

            var value = getObjectValue(data, params[0], args);
            var iteratorName = params[1];

            if (iteratorName.trim() == '') {
                console.error(wrongParametersMsg(args, 'for', attribute));
                return;
            }

            if (value == null) return;
            if (!(value instanceof Array)) {
                console.error(wrongTypeMsg(args, 'for', attribute, 'array'));
                return;
            }

            var id = element.getAttribute('w-id');
            if (id == null) {
                id = getId();
                element.setAttribute('w-id', id);
                forTemplateArray[id] = element.outerHTML;
            }

            var tempControl = null;

            switch (element.parentNode.tagName.toUpperCase()) {
                case 'SELECT':
                    tempControl = document.createElement('DIV');
                    tempControl.innerHTML = '<select>' + forTemplateArray[id] + '</select>';
                    tempControl = tempControl.childNodes[0];
                    break;
                case 'TR':
                    tempControl = document.createElement('DIV');
                    tempControl.innerHTML = '<table><tbody><tr>' + forTemplateArray[id] + '</tr></tbody></table>';
                    tempControl = tempControl.childNodes[0].childNodes[0].childNodes[0];
                    break;
                default:
                    tempControl = document.createElement(element.parentNode.tagName);
                    tempControl.innerHTML = forTemplateArray[id];
                    break;
            }

            tempControl = tempControl.childNodes[0];

            //Validando que el value no sea nulo, sea un array y no este vacio
            if (value.length > 0) {
                var valueCount = value.length - 1;
                var i = 0;
                var iteratorValue = {};
                var iteratorElement = tempControl.cloneNode(true); //Creo una nueva copia del element a iterar
                var parentNode = element.parentNode; //Obtengo el padre donde se insertara los nuevos elementos
                var path = params[0]; //Obtengo el path del objeto

                args.scope.push(data); //Al crear un for se crea un nuevo scope del iterador

                //A los elementos se les agregará el atributo w-ignore para que sean eliminados al actualizar
                for (i = 0; i < valueCount; i++) {
                    iteratorValue[iteratorName] = value[i];
                    iteratorElement.setAttribute('w-for-index', i);
                    iteratorElement.setAttribute('w-ignore', path); //Atributo w-ignore con la ruta a ignorar
                    iteratorElement.removeAttribute('w-for');
                    iteratorElement.removeAttribute('w-id');
                    parentNode.insertBefore(iteratorElement, element);
                    args.path = iteratorName;
                    args.pathLength = iteratorName.length;
                    args.cPrms.worker(iteratorElement, iteratorValue, args);
                    iteratorElement = tempControl.cloneNode(true);
                }

                //Solo al ultimo elemento no se le agrega para que se ejecute el for nuevamente al actualizar
                iteratorValue[iteratorName] = value[valueCount];
                iteratorElement.setAttribute('w-for-index', valueCount);
                parentNode.insertBefore(iteratorElement, element);
                args.path = iteratorName; //Seteo la ruta del scope inferior (variable de iteración del for)
                args.pathLength = iteratorName.length; //Seteo el tamaño del path para no calcularlo dentro del worker
                args.cPrms.worker(iteratorElement, iteratorValue, args);  //Llamo al worker para que trabaje en los elementos hijos

                args.scope.pop(); //Como ya termino el for elimino el scope inferior que se creo

                parentNode.removeChild(element); //Elimino el elemento base con el cual se creo los demas
            }
            else {
                element.style.display = 'none';
            }
        }

        //Ejecuta la función w-autocomplete="path:variableIteracion" 
        function doAutocomplete(element, data, args, attribute) {
            var params = attribute.split(separatorParam);
            var arrayValue = null;
            var iterateValue = null;
            var getArrayItem = null;
            var currentIndex = -1;

            if (params.length < 1 || params.length > 2) {
                console.error(wrongParametersMsg(args, 'autocomplete', attribute));
                return;
            }

            if (element.tagName != 'INPUT' || element.type == 'checkbox') {
                console.error(args.getFullName() + ': Can not add autocomplete to the following element: ' + element.outerHTML);
                return;
            }

            arrayValue = getObjectValue(data, params[0], args);

            if (!(arrayValue instanceof Array)) {
                console.error(wrongTypeMsg(args, 'autocomplete', attribute, 'array'));
                return;
            }

            if (params.length == 2) {
                iterateValue = params[1];
                getArrayItem = function (i) { return arrayValue[i][iterateValue]; };
            }
            else {
                getArrayItem = function (i) { return arrayValue[i]; };
            }

            function removeControl() {
                var control = element.parentNode.querySelector('.auto-complete');
                if (control) element.parentNode.removeChild(control);

                document.body.removeEventListener('click', removeControl);
            }

            function updateIndex(change) {
                var control = element.parentNode.querySelector('.auto-complete');
                if (control == null) return;

                if (currentIndex >= 0) control.childNodes[currentIndex].className = null;

                currentIndex = Math.max(currentIndex + change, -1);

                if (currentIndex >= 0) control.childNodes[currentIndex].className = 'selected';
            }

            function createChild(control, value) {
                if (value.toLowerCase().indexOf(element.value.toLowerCase()) == -1) return;

                var innerControl = document.createElement('div');

                innerControl.innerText = value;
                innerControl.onclick = function () {
                    element.value = value; element.focus();
                    worker.interop.method.forceChange(element, 'input');
                    removeControl();
                };

                control.appendChild(innerControl);
            }

            function callback() {
                var arrayLength = arrayValue.length;
                var i = 0;
                var control = document.createElement('div');

                removeControl();

                if (arrayLength == 0) return;

                currentIndex = 0;
                control.className = 'auto-complete';

                while (i < arrayLength && control.childNodes.length < 10) {
                    createChild(control, getArrayItem(i));
                    i++;
                }

                if (element.nextSibling) element.parentNode.insertBefore(control, element.nextSibling);
                else element.parentNode.appendChild(control);

                if (control.childNodes.length > 0) control.childNodes[0].className = 'selected';

                bindEvent(document.body, 'click', removeControl);
            }

            bindEvent(element, 'input', callback);
            bindEvent(element, 'keydown', function (e) {
                if (e.keyCode == 40) { updateIndex(1); }
                else if (e.keyCode == 38) { updateIndex(-1); }
                else if (e.keyCode == 13 || e.keyCode == 9) {
                    var control = element.parentNode.querySelector('.auto-complete');
                    if (control == null) return;

                    if (currentIndex >= 0 && control.childNodes[currentIndex]) control.childNodes[currentIndex].click();
                    else removeControl();
                }
            });
        }

        //Ejecuta la función w-attr en modo creación
        function doAttrCreate(element, data, args) {
            var attribute = element.getAttribute('w-attr');

            if (attribute) { doAttr(element, data, args, attribute); }
        }

        function doSort(element, data, args, attribute) {
            var params = attribute.split(separatorParam);
            var value = null;
            var fn = null;
            var sortData = null;
            var isAsc = true;
            var path = null;

            if (params.length == 3) {
                path = params[0].replace(/\./g, '_');
                sortData = args.sort[path];

                if (sortData.active) return;
                else if (sortData.id == element.getAttribute('w-sort-id')) isAsc = sortData.asc = (!sortData.asc);
                else {
                    sortData.id = element.getAttribute('w-sort-id');
                    isAsc = sortData.asc = true;
                }

                if ((value = getObjectValue(data, params[0], args)) == null) return;
                else if (!(value instanceof Array)) {
                    console.error(wrongTypeMsg(args, 'sort', attribute, 'array'));
                    return;
                }
                else if (value.length == 0) return;

                if (!((fn = getValue(data, params[1], args)) && fn instanceof Function)) {
                    fn = function (a, b) {
                        var rslt = 0;

                        if (a[params[1]] > b[params[1]]) rslt = 1;
                        else if (a[params[1]] == b[params[1]]) return 0;
                        else rslt = -1;

                        return isAsc ? rslt : -rslt;
                    }
                }

                value.sort(fn);

                sortData.active = true;
                args.worker.update(params[0]);
                sortData.active = false;

            }
            else {
                console.error(wrongParametersMsg(args, 'sort', attribute));
                return;
            }
        }

        //Ejecuta la función w-style en modo creación
        function doStyleCreate(element, data, args) {
            var attribute = element.getAttribute('w-style');

            if (attribute) { doStyle(element, data, args, attribute); }
        }

        //Ejecuta la función w-if en modo creación
        function doIfCreate(element, data, args) {
            var attribute = element.getAttribute('w-if');

            if (attribute) {
                if (element.style.display != 'none') element.setAttribute('w-if-default', element.style.display);
                doIf(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-enabled en modo creación
        function doEnabledCreate(element, data, args) {
            var attribute = element.getAttribute('w-enabled');

            if (attribute) { doEnabled(element, data, args, attribute); }
        }

        //Ejecuta la función w-class en modo creación
        function doClassCreate(element, data, args) {
            var attribute = element.getAttribute('w-class');

            if (attribute) {
                if (element.className) element.setAttribute('w-class-base', element.className);
                doClass(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-bind en modo creación
        function doBindCreate(element, data, args) {
            var attribute = element.getAttribute('w-bind');

            if (attribute) { doBind(element, data, args, attribute); }
        }

        //Ejecuta la función w-on en modo creación
        function doOnCreate(element, data, args) {
            var attribute = element.getAttribute('w-on');

            if (attribute) { doOn(element, data, args, attribute); }
        }

        //Ejecuta la función w-model en modo creación
        function doModelCreate(element, data, args) {
            var attribute = element.getAttribute('w-model');

            if (attribute && element.getAttribute('w-bind') == null) {
                doModel(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-autocomplete en modo creación
        function doAutocompleteCreate(element, data, args) {
            var attribute = element.getAttribute('w-autocomplete');

            if (attribute) {
                doAutocomplete(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-if en modo creación
        function doSortCreate(element, data, args) {
            var attribute = element.getAttribute('w-sort');
            var params = null;
            var path = null;

            if (attribute && (params = attribute.split(separatorParam)).length == 3) {
                path = params[0].replace(/\./g, '_');
                data = args.scope.length > 0 ? args.scope[0] : data;

                element.addEventListener(params[2], function () { doSort(element, data, args, attribute); });
                if (args.sort == null) args.sort = {};
                if (args.sort[path] == null) args.sort[path] = { asc: false, id: null, active: false };
                element.setAttribute('w-sort-id', getId());
            }
        }

        //Ejecuta la función w-for en modo creación
        function doForCreate(element, data, args) {
            var attribute = element.getAttribute('w-for');

            if (attribute && element.getAttribute('w-for-index') == null) {
                doFor(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-style en modo actualización
        function doStyleUpdate(element, data, args) {
            var attribute = element.getAttribute('w-style');

            if (attribute && isPathDependent(args, attribute)) {
                doStyle(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-if en modo actualización
        function doIfUpdate(element, data, args) {
            var attribute = element.getAttribute('w-if');
            var path;

            if (attribute != null && attribute.length > 0 && attribute[0] == '!') path = attribute.substr(1);
            else path = attribute;

            if (attribute && isPathDependent(args, path)) {
                doIf(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-enabled en modo actualización
        function doEnabledUpdate(element, data, args) {
            var attribute = element.getAttribute('w-enabled');

            if (attribute && isPathDependent(args, attribute)) {
                doEnabled(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-class en modo actualización
        function doClassUpdate(element, data, args) {
            var attribute = element.getAttribute('w-class');

            if (attribute && isPathDependent(args, attribute)) {
                doClass(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-bind en modo actualización
        function doBindUpdate(element, data, args) {
            var attribute = element.getAttribute('w-bind');

            if (attribute && isPathDependent(args, attribute)) {
                doBind(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-on en modo actualización
        function doOnUpdate(element, data, args) {
            var attribute = element.getAttribute('w-on');

            if (attribute && isPathDependent(args, attribute)) {
                doOn(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-if en modo actualización
        function doSortUpdate(element, data, args) {
            var attribute = element.getAttribute('w-sort');

            if (attribute && isPathDependent(args, attribute)) {
                doSort(element, data, args, attribute);
            }
        }

        //Ejecuta la función w-for en modo actualización
        function doForUpdate(element, data, args) {
            var attribute = element.getAttribute('w-for');

            if (attribute && isPathDependent(args, attribute)) {
                doFor(element, data, args, attribute);
            }
        }

        //Agrega una función
        function addFunction(name, create, update) {
            name = name.toLowerCase();

            if (functionCreate[name] || functionUpdate[name]) {
                console.error('Core: The function "' + name + '" already exists.');
                return;
            }

            if (create) functionCreate[name] = create;
            if (update) functionUpdate[name] = update;
        }

        function init() {
            functionCreate.attr = doAttrCreate;
            functionCreate.style = doStyleCreate;
            functionCreate['if'] = doIfCreate;
            functionCreate.enabled = doEnabledCreate;
            functionCreate['class'] = doClassCreate;
            functionCreate.bind = doBindCreate;
            functionCreate.model = doModelCreate;
            functionCreate.on = doOnCreate;
            functionCreate.autocomplete = doAutocompleteCreate;
            functionCreate.sort = doSortCreate;
            functionCreate['for'] = doForCreate;

            functionUpdate.style = doStyleUpdate;
            functionUpdate['if'] = doIfUpdate;
            functionUpdate.enabled = doEnabledUpdate;
            functionUpdate['class'] = doClassUpdate;
            functionUpdate.bind = doBindUpdate;
            functionUpdate.on = doOnUpdate;
            functionUpdate.sort = doSortUpdate;
            functionUpdate['for'] = doForUpdate;

            worker.addFunction = addFunction;
        }

        init();
    }

    //Inicializa las funciones propias que manejaran las vistas
    function initViewHandlers() {

        //Crea el objeto event handler que hereda del objeto event handler
        function getViewObject(element, viewConfig, worker, extra) {
            var viewObject = getEventHandlerObject('view');

            viewObject.name = viewConfig.name;
            viewObject.el = element;
            viewObject.worker = worker;
            viewObject.getFullName = function () { return 'Controller: ' + viewObject.name + '/' + viewObject.id; };

            viewObject.template = null;
            viewObject.prms = null;
            viewObject.scope = [];
            viewObject.extra = extra;

            viewObject.setHook('afterCreate', workerObject, function () { viewObject.el.setAttribute('w-id', viewObject.id); });

            return viewObject;
        }

        //Crea el HTML de manera recursiva
        function doCreate(element, data, view) {
            if (element.getAttribute('w-view-ignore')) return;

            var i = null;
            var c = null;
            var childViewName = element.getAttribute('w-view');
            var childViewConfig = childViewName ? viewArray[childViewName] : null; //Revisa que exista el atributo y lo instancia en base a eso

            //Si existe la vista hace algunas validaciones
            if (childViewConfig) {
                var prms = element.getAttribute('w-params');
                var prm = null;

                if (prms) {
                    prms = prms.split(separatorParam);

                    for (i = 0; i < prms.length; i++) {
                        prm = getValue(data, prms[i], view);

                        if (prm == null) break;

                        prms[i] = prm;
                    }
                }

                //Si sucede esto es porque algún parametro es nulo y por ende la vista no se debe ejecutar en este scope
                if (prms == null || i == prms.length) {
                    doView(element, childViewConfig, prms, { type: 'parent', id: view.extra == null || view.extra.type != 'parent' ? view.id : view.extra.id });
                    return;
                }
            }

            c = element.children && childViewConfig == null ? element.children.length : 0;

            //Se ejecuta los hijos primero en caso hubiese
            if (c > 0) {
                //Guarda los hijos en un Array para que en caso exista un for no confunda los hijos agregados recientemente
                var childrens = [];
                for (i = 0; i < c; i++) childrens.push(element.children[i]);

                for (i = 0; i < c; i++) doCreate(childrens[i], data, view);

            }

            //Se ejecuta las funciones configuradas en la creación del worker
            for (i = 0; i < view.cPrms.fnCount; i++) {
                view.cPrms.fn[i](element, data, view);
            }
        }

        //Actualiza el HTML de manera recursiva
        function doUpdate(element, data, view) {
            var childrens = null;
            var path = element.getAttribute('w-ignore');
            var i = null;
            var c = null;
            var childViewName = element.getAttribute('w-view');
            var childParams = element.getAttribute('w-params');
            var childParam = null;
            var childId = null;
            var childView = null;

            //Si el elemento tiene el w-ignore y es afectado por este path, se elimina ya que pertenece a un for y no es el elemento base
            if (path && isPathDependent(view, path)) {
                childId = childViewName ? element.getAttribute('w-id') : null;
                childView = childId ? workerArray[childId] : null;

                if (childView) childView.invoke('beforeRemove');
                element.parentNode.removeChild(element);
                if (childView) childView.invoke('afterRemove');

                return;
            }

            if (childViewName) {
                if (childParams == null || element.getAttribute('w-id')) return;
                else {
                    childParams = childParams.split(separatorParam);
                    c = childParams.length;
                    path = false;

                    for (i = 0; i < c; i++) {
                        childParam = getValue(data, childParams[i], view);

                        if (childParam == null) break;

                        childParams[i] = childParam;
                        path = path || isPathDependent(view, childParams[i]);
                    }

                    //Si sucede esto es porque algún parametro es nulo y por ende la vista no se debe ejecutar en este scope
                    if (path && i == childParams.length) {
                        childView = workerArray[element.getAttribute('w-id')];

                        childView.invoke('beforeRemove');
                        doView(element, viewArray[childViewName], childParams, { type: 'parent', id: view.extra == null || view.extra.type != 'parent' ? view.id : view.extra.id });
                        childView.invoke('afterRemove');

                        return;
                    }
                }
            }

            i = 0;
            c = element.children ? element.children.length : 0;

            path = view.path;
            view.pathLength = path.length;

            //Primero se ejecuta los hijos en caso tuviese
            if (c > 0) {
                childrens = [];

                //Guarda los hijos en un array para que no se vea afectado por los hijos agregados recientemente por un for
                for (i = 0; i < c; i++) childrens.push(element.children[i]);

                for (i = 0; i < c; i++) doUpdate(childrens[i], data, view);
            }

            for (i = 0; i < view.uPrms.fnCount; i++) {
                view.uPrms.fn[i](element, data, view);

                //Se setea nuevamente la data del path en caso un for lo haya cambiado por el scope
                view.path = path;
                view.pathLength = path.length;
            }

        }

        //Genera un elemento view de los agregados
        function doView(element, viewConfig, parameters, extra) {
            var data = {};
            var worker = {};
            var ctrlParameters = [data, worker];
            var view = getViewObject(element, viewConfig, worker, extra);
            var i = null;

            view.cPrms = viewConfig.create;
            view.uPrms = viewConfig.update;

            //Agrega los servicios como parametros para el controlador
            for (i = 0; i < viewConfig.servicesLength; i++)
                ctrlParameters.push(viewConfig.services[i](view));

            //Agrega los argumentos para que pasen como constructor
            if (parameters && parameters.length > 0)
                for (i = 0; i < parameters.length; i++)
                    ctrlParameters.push(parameters[i]);

            //Enlace de eventos del ciclo de vida de la vista
            function setHook(eventName, callback) {
                view.setHook(eventName, view, callback);
            }

            //Desenlace de eventos del ciclo de vida de la vista
            function removeHook(eventName) {
                view.removeHook(eventName, view, callback);
            }

            //Función de creación para el worker
            function create() {
                var elements = view.el.querySelectorAll('[w-view]');
                var innerViews = [];
                var i = 0;
                var c = elements.length;

                view.invoke('beforeCreate');

                view.prms = viewConfig.create; //Parametros de creación

                for (i = 0; i < c; i++) {
                    innerViews.push(elements[i].getAttribute('w-id') ? workerArray[elements[i].getAttribute('w-id')] : null);
                    if (innerViews[i]) innerViews[i].invoke('beforeRemove');
                }

                view.el.innerHTML = view.template; //Setea el HTML en el elemento padre

                for (i = 0; i < c; i++) {
                    if (innerViews[i]) innerViews[i].invoke('afterRemove');
                }

                view.el.removeAttribute('w-view');
                doCreate(view.el, data, view); //Ejecuta la creación
                view.el.setAttribute('w-view', view.name);

                view.invoke('afterCreate');
            }

            //Función de actualización para el worker
            function update(path) {
                view.invoke('beforeUpdate');

                //Valida que el path no este vacio o nulo
                if (path == null || path.trim() == '') {
                    console.error(view.getFullName() + ': Can not update with a null path.');
                }

                view.prms = viewConfig.update; //Parametros de actualización

                //Setea el path a verificar
                view.path = path;
                view.pathLength = path.length;

                view.el.removeAttribute('w-view');
                doUpdate(view.el, data, view); //Ejecuta la actualización
                view.el.setAttribute('w-view', view.name);

                view.invoke('afterUpdate', [path]); //Hace la llamada al evento
            }

            worker.setHook = setHook;
            worker.removeHook = removeHook;
            worker.update = update;
            worker.create = create;
            worker.id = view.id;

            //Verifica si el template es null para tomarlo de los existentes del DOM
            if (viewConfig.template == null) {
                view.template = element.innerHTML;

                if (view.template == null) {
                    console.error(view.getFullName() + ': Can not instance the view because there is no template on the DOM.');
                    return;
                }
            }
            //Si es una función ya que lo trae desde una URL adapta la función de creación
            else if (viewConfig.template instanceof Function) {
                worker.create = function () { viewConfig.template(view, create); };
            }
            else view.template = viewConfig.template;

            viewConfig.ctrl.apply(null, ctrlParameters); //Ejecuta el controlador

            if (viewConfig.autoCreate) worker.create(); //Crea la vista
        }

        //Agrega el controlador de una vista
        function addView(name, config, ctrl) {
            //Hace una verificación previa ya que si el controlador es nulo el parametro config debe ser el controlador
            if (ctrl == null) { ctrl = config; config = null; }

            //Verifica que los parametros sean los correctos
            if (name == null || !(ctrl instanceof Function)) {
                console.error('Core: Wrong parameters on "' + name + '" view declaration.');
                return;
            }

            //Verifica que no exista dos vistas iguales
            if (viewArray[name]) {
                console.error(moreThanOneMsg('view', name, 'views'));
                return;
            }

            var view = {
                name: name,
                ctrl: ctrl,
                create: { fn: [], worker: doCreate },
                update: { fn: [], worker: doUpdate },
                services: [],
                autoCreate: worker.prms.autoCreate
            };
            var i = 0;

            if (config != null) {

                //Si es un array lo setea ya que son las funciones a usar
                if (config instanceof Array) {
                    view.fn = config;
                }
                //Si es un objeto revisa los parametros
                else if (config instanceof Object) {
                    view.fn = config.fn;

                    //Revisa si el template esta como cadena
                    if (config.template) {
                        view.template = config.template;
                    }
                    //Revisa el template esta como un URL de ser asi crea la función que lo traera para integrarse con la vista
                    else if (config.templateUrl) {
                        view.template = function (args, create) {
                            functionService['http'].get(config.templateUrl).then(
                                function (data) {
                                    args.template = data;

                                    create();
                                },
                                function (error) {
                                    console.error(args.getFullName() + ': Could not get the template from "' + config.templateUrl + '".');
                                    console.error(error);
                                });
                        };
                    }

                    view.autoCreate = config.autoCreate == null ? true : config.autoCreate;
                }

                //Si el config es un Array es porque son las funciones del controlador
                if (view.fn != null && !(view.fn instanceof Array)) {
                    console.error('Core: The functions in the config parameters in the view "' + name + '" are incorrect.');
                    return;
                }
            }

            //Revisa por las funciones y servicios
            if (view.fn) {

                var fnStr = ',bind,';
                var fnAux = {};
                var fnName = null;

                for (i = 0; i < view.fn.length; i++) {
                    fnName = view.fn[i].toLowerCase();

                    if (fnAux[fnName]) {
                        console.error('Core: There is more than one function with the name "' + fnName + '" on the view "' + name + '".');
                        return;
                    }
                    else {
                        if (functionService[fnName]) {
                            view.services.push(functionService[fnName]);
                        }
                        else {
                            fnStr += fnName + ',';
                        }
                    }

                    fnAux[fnName] = true;
                }

                for (i in functionCreate)
                    if (fnStr.indexOf(',' + i + ',') != -1)
                        view.create.fn.push(functionCreate[i]);

                for (i in functionUpdate)
                    if (fnStr.indexOf(',' + i + ',') != -1)
                        view.update.fn.push(functionUpdate[i]);

                view.servicesLength = view.services.length;
            }
            else {
                view.create.fn.push(functionCreate['bind']);
                view.update.fn.push(functionUpdate['bind']);
            }

            view.create.fnCount = view.create.fn.length;
            view.update.fnCount = view.update.fn.length;

            //Crea la vista
            viewArray[name] = view;
        }

        function init() {
            worker.interop['do'].view = doView;
            worker.addView = addView;
        }

        init();
    }

    //Agrega un servicio
    function addService(name, fn) {
        name = name.toLowerCase();

        if (functionService[name]) {
            console.error('Core: The service "' + name + '" already exists.');
            return;
        }

        if (fn && fn instanceof Function) functionService[name] = fn;
        else {
            console.error('Core: The service "' + name + '" is not a function.');
            return;
        }
    }

    //Verifica el DOM en caso de existencia de VIEWS
    function verifyDOM(element) {
        var attribute = element.getAttribute('w-view');

        if (attribute && viewArray[attribute] && element.getAttribute('w-view-ignore') == null) {
            worker.interop['do'].view(element, viewArray[attribute]);
            return;
        }

        var i = 0;
        var j = element.children.length;
        var elements = element.children;

        if (j > 0) for (i = 0; i < j; i++) verifyDOM(elements[i]);
    }

    //Realiza procesos en el cargado
    function onLoad() {

        if (!worker.prms.showNullValueLog) getNonNullValue = function (data) { return data; };

        verifyDOM(document.body);
    }

    function initEventService() {
        var eventId = getId();

        worker.addService('event', function (view) {
            var event = null;

            if (view.extra && view.extra.type == 'parent') {
                event = workerArray[view.extra.id][eventId];
            }

            if (event == null) {
                event = getEventHandlerObject();
                view[eventId] = event;
            }

            return event;
        });
    }

    //Funciones iniciales del framework
    function init() {
        workerObject = getWorkerObject('core');

        worker = {
            interop: {
                do: {},
                getId: getId,
                getView: function (viewName) { return viewArray[viewName]; },
                getObject: function (id) { return workerObject[id]; },
                method: {
                    forceChange: function (el, eventName) {
                        var event;
                        if (typeof (Event) === 'function') {
                            event = new Event(eventName);
                        } else {
                            event = document.createEvent('Event');
                            event.initEvent(eventName, true, true);
                        }
                        if (el.dispatchEvent) el.dispatchEvent(event);
                        else if (el.fireEvent) el.fireEvent(event);
                    },
                    bindEvent: bindEvent
                }
            },
            prms: {
                autoCreate: true,
                showNullValueLog: false
            }
        };

        worker.addService = addService;

        initAttributeHandlers();
        initViewHandlers();
        initEventService();

        bindEvent(window, 'load', onLoad);
    }

    init();

})();
//Servicio HTTP
(function () {

    //Envía una llamada asincrona a una url
    function send(method, url, data, headers, xhrFn) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();

            //Abre el canal de trasmisión
            xhr.open(method, url, true);

            if (xhrFn) xhrFn(xhr);

            //Escribe los headers si existiesen
            if (headers) {
                for (var i = 0; i < headers.length; i++) {
                    xhr.setRequestHeader(headers[i][0], headers[i][1]);
                }
            }

            //Configura la llamada del resolve y el reject en caso falle
            xhr.onreadystatechange = function (e) {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        resolve(xhr.response ? xhr.response : xhr.responseText);
                    }
                    else {
                        reject(Error('Http: Error al ejecutar la llamada: ' + xhr.statusText));
                    }
                }
            };

            //En caso falle por problemas de red
            xhr.onerror = function () {
                reject(Error('Http: Hay un problema en la conexión'));
            };

            //Envia la data
            xhr.send(data);
        });
    }

    //Envía una llamada tipo GET asincrona al url
    function get(url, data, headers) {
        return send('GET', url, data, headers);
    }

    //Envía una llamada tipo POST asincrona al url
    function post(url, data, headers) {
        return send('POST', url, data, headers);
    }

    function getFile(url, data, headers) {
        return send('GET', url, data, headers, function (xhr) { xhr.responseType = 'blob'; });
    }

    function postFile(url, data, headers) {
        return send('POST', url, data, headers, function (xhr) { xhr.responseType = 'blob'; });
    }

    worker.addService('http', function () {
        return { send: send, get: get, post: post, getFile: getFile, postFile: postFile };
    });

})();
//Servicio CSV
(function () {

    var rowSeparator = '¬';
    var colSeparator = '|';
    var tabSeparator = '^';

    var keySeparator = '%';

    var colKey = 'c';
    var rowKey = 'r';
    var tabKey = 't';

    var headersNames = ['TypeFunction', 'Width', 'Description', 'TypeName', 'PropertyName'];

    //Obtiene los headers de la consulta
    function splitHeaders(args) {
        var char = '';
        var cell = '';
        var row = {};
        var table = [];
        var i = 0;
        var j = 0;
        var headerName = headersNames[headersNames.length - 1];
        var isFirstHeader = true;

        while (i < args.headersCount && args.index < args.length) {
            args.index++; char = args.string[args.index];

            if (char === colSeparator) {
                row[headerName] = cell;

                if (isFirstHeader) { table.push(row); row = {}; }
                else { j++; row = table[j]; }

                cell = ''; continue;
            }

            if (char === rowSeparator) {
                row[headerName] = cell;

                if (isFirstHeader) { table.push(row); isFirstHeader = false; }

                row = table[0]; j = 0; i++; headerName = headersNames[headersNames.length - i - 1]; cell = ''; continue;
            }

            if (char === tabSeparator) break;

            if (char === keySeparator) {
                args.index++; char = args.string[args.index];

                if (char === colKey) char = colSeparator;
                else if (char === rowKey) char = rowSeparator;
                else if (char === tabKey) char = tabSeparator;
                else { char = keySeparator; args.index--; }
            }

            cell += char;
        }

        row[headerName] = cell;

        args.headers = table;
    }

    //Obtiene la función que convierte la cadena al tipo de dato solicitado
    function getTypeFunction(typeName) {
        switch (typeName) {
            case 'bit':
                return function (string) { return string ? string.toLowerCase() == 'true' : null; };
            case 'int':
            case 'decimal':
                return function (string) { return string ? parseFloat(string) : NaN; };
            case 'datetime':
            case 'date':
                return function (string) { return string ? new Date(parseInt(string)) : null; };
            default:
                return function (string) { return string; };
        }
    }

    function setCellValue(row, cell, parseFunction, propertyName) {
        row[propertyName] = parseFunction(cell);
    }

    //Obtiene el cuerpo de la consulta con su tipo respectivo
    function splitBodyWithType(args) {
        var headersCount = args.headers.length;
        var header = null;
        var typeName = headersNames[headersNames.length - 2];
        var functionName = headersNames[0];
        var propertyName = headersNames[headersNames.length - 1];
        var i = 0;

        for (i = 0; i < headersCount; i++) {
            header = args.headers[i];

            header[functionName] = getTypeFunction(header[typeName]);
        }

        var char = '';
        var cell = '';
        var row = {};
        var table = [];

        i = 0;
        header = args.headers[i];

        while (args.index < args.length) {
            args.index++; char = args.string[args.index];

            if (char === colSeparator) {
                if (row == null) row = {};

                setCellValue(row, cell, header[functionName], header[propertyName]);

                cell = ''; i++; header = args.headers[i]; continue;
            }

            if (char === rowSeparator) {
                setCellValue(row, cell, header[functionName], header[propertyName]); table.push(row);

                cell = ''; i = 0; header = args.headers[i]; row = null; continue;
            }

            if (char === tabSeparator) {
                setCellValue(row, cell, header[functionName], header[propertyName]); table.push(row);

                cell = null; row = null; break;
            }

            if (char === keySeparator) {
                args.index++; char = args.string[args.index];

                if (char === colKey) char = colSeparator;
                else if (char === rowKey) char = rowSeparator;
                else if (char === tabKey) char = tabSeparator;
                else { char = keySeparator; args.index--; }
            }

            cell += char;
        }

        if (args.length === args.index && row != null) {
            setCellValue(row, cell, header[functionName], header[propertyName]); table.push(row);

            cell = null; row = null;
        }

        args.table = table;
    }

    //Hace el split de N tablas en un contenedor
    function split(string, container) {
        var args = {};
        var listCount = 0;
        var i = 0;
        var char = '';
        var name = '';
        var tableNames = [];

        args.string = string;
        args.length = string.length - 1;
        args.index = -1;

        while (args.index < args.length) {
            args.index++; char = args.string[args.index];

            if (char === colSeparator) {
                tableNames.push(name);

                name = ''; listCount++;
                continue;
            }
            if (char === tabSeparator) {
                tableNames.push(name);

                name = ''; listCount++;
                break;
            }

            name += char;
        }

        for (i = 0; i < listCount; i++) {
            name = tableNames[i];

            args.index++; args.headersCount = parseInt(args.string[args.index]);
            splitHeaders(args);

            if (args.string[args.index] === tabSeparator) args.table = [];
            else if (args.headersCount > 1) splitBodyWithType(args);

            container[name] = { Headers: args.headers, Items: args.table };
        }
    }

    worker.addService('csv', function () {
        return { split: split };
    });
})();
//Servicio MODAL
(function () {

    var classModal = 'modal fade';
    var classBody = 'modal-open';
    var classBackground = 'modal-backdrop fade';

    var oldClassBody = null;

    var templateArray = {};
    var modalArray = {};
    var modalOrderArray = [];
    var background = null;
    var isClosing = false;
    var isOpening = false;
    var bindEvent = worker.interop.method.bindEvent;

    function getLastModal() {
        return modalArray[modalOrderArray[modalOrderArray.length - 1]];
    }

    function getShowFunction(modal) {
        var el = modal.el;

        el.className = classModal;
        el.setAttribute('tabindex', '-1');
        el.style = null;

        return function () {
            isOpening = true;
            modal.invoke('beforeShow');

            if (background == null) {
                background = document.createElement('div');

                background.className = classBackground + ' in';
                document.body.appendChild(background);

                oldClassBody = document.body.className;
                document.body.className = (oldClassBody ? oldClassBody + ' ' : '') + classBody;

                addModal(modal);
            }
            else {
                if (isClosing) { isClosing = false; background.className = classBackground + ' in'; addModal(modal); return; }
                var lastModal = getLastModal();

                lastModal.el.className = classModal;

                setTimeout(function () { addModal(modal); }, 150);
            }
        };
    }

    function removeModalRef(modal) {
        modalOrderArray.splice(modal.index, 1);
        modalArray[modal.extra.id] = undefined;
    }

    function removeModal(modal) {
        modal.invoke('afterClose');

        document.body.removeChild(modal.el);

        modal.invoke('afterRemove');
    }

    function addModal(modal) {
        modal.el.className = classModal + ' in';
        modal.el.style.display = 'block';
        modal.el.style.paddingRight = '17px';

        modal.index = modalOrderArray.length;
        modalOrderArray.push(modal.extra.id);
        modal.invoke('afterShow');
    }

    function closeModal(modal, prms) {
        isClosing = true;
        isOpening = false;

        modal.invoke('beforeClose', prms);

        if (modal.index + 1 == modalOrderArray.length) {
            modal.el.className = classModal;

            if (modalOrderArray.length == 1) background.className = classBackground;

            removeModalRef(modal);

            setTimeout(function () {
                removeModal(modal);

                if (modalOrderArray.length == 0) {
                    if (isOpening) { isOpening = false; return; }

                    document.body.removeChild(background);
                    document.body.className = oldClassBody;
                    background = null;
                }
                else {
                    modal = getLastModal();

                    modal.el.className = classModal + ' in';
                }

            }, 150);
        }
        else {
            removeModalRef(modal);
            removeModal(modal);
        }
    }

    function initTemplates() {
        var elements = document.querySelectorAll('[w-modal]');
        var element = null;
        var i = 0;
        var c = elements.length;
        var modalName = null;

        for (i = 0; i < c; i++) {
            element = elements[i];
            modalName = element.getAttribute('w-modal');

            if (templateArray[modalName]) {
                console.error('Modal: There is already a modal with the name "' + modalName + '".');
                continue;
            }

            templateArray[modalName] = element.innerHTML;

            element.parentNode.removeChild(element);
        }
    }

    function init() {
        bindEvent(window, 'load', initTemplates);
    }

    worker.addService('modal', function (view) {
        var modal = null;
        var service = {};

        if (view.extra && view.extra.type == 'modal') {
            modalArray[view.extra.id] = view;
            modal = view;
        }

        service.create = function (name, args) {
            if (args == null) args = {};

            var id = worker.interop.getId();
            var view = worker.interop.getView(name);
            var el = null;

            if (view == null) {
                console.error('Modal: There is no view called "' + name + '".');
                return;
            }

            if (view.template == null) view.template = templateArray[name];

            el = document.createElement('div');

            if (background) document.body.insertBefore(el, background);
            else document.body.appendChild(el);

            worker.interop['do'].view(el, view, args.prms, { type: 'modal', id: id });

            return modalArray[id];
        };

        if (modal != null) {
            modal.show = getShowFunction(modal);
            modal.close = function (prms) {
                closeModal(modal, prms);
            };

            service.show = modal.show;
            service.close = modal.close;
        }

        return service;
    });

    init();

})();
//Servicio WAIT
(function () {

    var classLoading = 'view-wait';

    worker.addService('wait', function (view) {

        var svc = {
            state: false,
            x: 0,
            y: 0,
            set: function (value) {
                var el = view.el;

                if (el.className.indexOf(classLoading) == -1 && value) {
                    svc.x = window.pageXOffset || document.documentElement.scrollLeft;
                    svc.y = window.pageYOffset || document.documentElement.scrollTop;
                    svc.state = true;
                    el.className = (el.className ? el.className + ' ' : '') + classLoading;
                }
                else if (el.className.indexOf(classLoading) != -1 && !value) {
                    svc.state = false;
                    el.className = el.className == classLoading ? '' : el.className.replace(' ' + classLoading, '');
                    setTimeout(svc.scroll, 100);
                }
            },
            scroll: function () {
                if (svc.y > 0) document.documentElement.scrollTop = document.body.scrollTop = svc.y;
                if (svc.x > 0) document.documentElement.scrollLeft = document.body.scrollLeft = svc.x;
            }
        };

        return svc;
    });

})();
//Servicio DATEPICKER
(function () {

    var daysOfWeek = ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'];
    var months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    var template = '<table><thead><tr><th class="date-col" w-on="PreviousYear:click"><</th><th class="date-month" w-bind="Year" colspan="5"></th><th class="date-col" w-on="NextYear:click">></th></tr><tr><th class="date-col" w-on="PreviousMonth:click"><</th><th class="date-month" w-bind="MonthName" colspan="5"></th><th class="date-col" w-on="NextMonth:click">></th></tr><tr><th class="date-col" w-for="Days:DayName" w-bind="DayName"></th></tr></thead><tbody><tr w-for="Weeks:Week"><td w-for="Week:WeekDay" w-bind="WeekDay.Value" w-on="WeekDay.Click:click:WeekDay" w-class="WeekDay.Class"></td></tr></tbody></table>';
    var functions = ['on', 'for', 'class', 'datepicker'];
    var $view = null;
    var $data = null;
    var bindEvent = worker.interop.method.bindEvent;

    function dateToString(date) {
        if (!(date instanceof Date)) return date;
        var string = '';

        string += (date.getDate() > 9 ? '' : '0') + date.getDate() + '/';
        string += (date.getMonth() > 8 ? '' : '0') + (date.getMonth() + 1) + '/';
        string += date.getFullYear();

        return string;
    }

    function stringToDate(string) {
        try {
            string = string.split('/');

            if (string.length != 3) return new Date();

            return new Date(parseInt(string[2]), parseInt(string[1]) - 1, parseInt(string[0]));
        }
        catch (e) {
            return new Date();
        }
    }

    function validateDate(string) {
        if (string instanceof Date) return true;

        try {
            string = string.split('/');

            if (string.length != 3) return false;

            var days = string[0] * 1;
            var months = string[1] * 1;
            var years = string[2] * 1;

            if (isNaN(days) || isNaN(months) || isNaN(years)) return false;

            if (days < 1 || days > 31 || months < 1 || months > 12 || years < 1970 || years > 9999) return false;

            return true;
        }
        catch (e) {
            return false;
        }

    }

    function controller(data, $worker) {

        function getMonthsDaysCount(monthChange) {
            var month = $data.Month + monthChange ? monthChange : 0;

            if (month == 1) return 28 + ($data.Year % 4 == 0 ? 1 : 0);
            else return month % 2 == 0 ? 30 : 31;
        }

        function refreshData(monthChange) {

            if (monthChange) {
                $data.Month += monthChange;

                if ($data.Month == 12) { $data.Month = 0; $data.Year++; }
                else if ($data.Month == -1) { $data.Month = 11; $data.Year--; }
            }

            $data.MonthName = months[$data.Month];
            $data.Weeks = [];

            var auxDate = new Date($data.Year, $data.Month, 1);
            var aux1 = auxDate.getDay();
            var aux2 = 0;
            var week = [];

            if (aux1 > 0) {
                aux2 = getMonthsDaysCount(-1);
                aux1 = aux2 - aux1;

                while (aux2 > aux1) {
                    aux1++;

                    week.push({
                        Value: aux1,
                        Class: 'other',
                        Click: function (day) { $data.Day = day.Value; refreshData(-1); $worker.create(); }
                    });
                }
            }

            aux1 = 0;
            aux2 = getMonthsDaysCount();

            while (aux2 > aux1) {
                aux1++;

                week.push({
                    Value: aux1,
                    Class: '',
                    Click: function (day) {
                        if ($data.Date) $data.Date.Class = '';

                        $data.Date = day;
                        $data.Date.Class = 'selected';
                        $data.Day = day.Value;

                        $worker.create();
                    }
                });

                if (aux1 == $data.Day) {
                    $data.Date = week[week.length - 1];
                    $data.Date.Class = 'selected';
                }

                if (week.length == 7) {
                    $data.Weeks.push(week);
                    week = [];
                }
            }

            if (week.length != 0) {
                aux1 = 0;

                while (week.length != 7) {
                    week.push({
                        Value: aux1 + 1,
                        Class: 'other',
                        Click: function (day) { $data.Day = day.Value; refreshData(1); $worker.create(); }
                    });

                    aux1++;
                }

                $data.Weeks.push(week);
            }
        }

        function afterCreate() {
            if ($data.Day) {
                $view.input.value = $view.data.dateToString(new Date($data.Year, $data.Month, $data.Day));
                worker.interop.method.forceChange($view.input, 'input');
            }

            $view.input.focus();
        }

        function init() {
            $data = data;
            $data.Days = daysOfWeek;
            $view.refreshData = refreshData;
            $worker.setHook('afterCreate', afterCreate);

            $data.NextYear = nextYear;
            $data.PreviousYear = previousYear;
            $data.NextMonth = nextMonth;
            $data.PreviousMonth = previousMonth;
        }

        function nextYear() {
            $data.Day = null;
            $data.Year++;

            refreshData();
            $worker.create();
        }

        function previousYear() {
            $data.Day = null;
            $data.Year--;

            refreshData();
            $worker.create();
        }

        function nextMonth() {
            $data.Day = null;

            refreshData(1);
            $worker.create();
        }

        function previousMonth() {
            $data.Day = null;

            refreshData(-1);
            $worker.create();
        }

        init();
    }

    function removeControl() {
        if ($view.isFirst) { $view.isFirst = false; return; }

        var elements = document.querySelectorAll('[w-view="datepicker"]');
        var i = 0;
        var c = elements.length;

        for (i = 0; i < c; i++)
            elements[i].parentNode.removeChild(elements[i]);

        document.body.removeEventListener('click', removeControl);

        $view.el = null;
        $view.input = null;
    }

    function inputKeyDown() {
        $view.isFirst = false;
        removeControl();
    }

    function showPicker(element, input, view) {
        var date = null;

        $view.isFirst = element.querySelector('[w-view="datepicker"]') != null;

        if ($view.isFirst) return true;

        $view.view = view;
        $view.data = view[$view.id];

        var control = document.querySelector('[w-view="datepicker"]');
        if (control) removeControl();

        control = document.createElement('div');
        control.className = 'date-table';

        if (input.nextSibling) input.parentNode.insertBefore(control, input.nextSibling);
        else input.parentNode.appendChild(control);

        date = stringToDate(input.value);

        $data.Year = date.getFullYear();
        $data.Month = date.getMonth();
        $data.Day = date.getDate();

        $view.el = control;
        $view.input = input;

        $view.refreshData();
        $view.worker.create();

        bindEvent(document.body, 'click', removeControl);
    }

    function setPickerEvent(view, element) {
        var showPickerFunction = null;
        var input = element.querySelector('input');

        if (input == null) {
            console.error('DatePicker: on the view "' + view.getFullName() + '" could not find any input element in the following HTML: ' + element.innerHTML);
            return;
        }

        showPickerFunction = function () { showPicker(element, input, view); };

        bindEvent(element, 'click', showPickerFunction);

        bindEvent(input, 'focus', showPickerFunction);
        bindEvent(input, 'keydown', inputKeyDown);
    }

    function verifyPickers(view) {
        var elements = view.el.querySelectorAll('.form-date');
        var i = 0;
        var c = elements.length;

        for (i = 0; i < c; i++) setPickerEvent(view, elements[i]);
    }

    function service(view) {
        if (view.name == 'datepicker') { $view = view; return view; }

        view.setHook('afterCreate', $view, function () { verifyPickers(view); });

        view[$view.id] = { dateToString: dateToString, stringToDate: stringToDate, validate: validateDate };

        return view[$view.id];
    }

    function init() {
        worker.date = { dateToString: dateToString, stringToDate: stringToDate, validate: validateDate };
        worker.addService('datepicker', service);
        worker.addView('datepicker', { fn: functions, template: template, autoCreate: false }, controller);

        worker.interop['do'].view(null, worker.interop.getView('datepicker'));
    }

    init();

})();
